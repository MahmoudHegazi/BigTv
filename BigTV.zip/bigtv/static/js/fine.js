$(document).ready(function() {

	$('#searchForm').on('submit', function(event) {
		
		$.ajax({
			data : {
				search : $('#nameInput').val(),
			},
			type : 'POST',
			url : '/process'
		})
		.done(function(data) {

			if (data.error) {
				$('#errorAlert').text(data.error).show();
				$('#successAlert').hide();
				
			}
			else {
				$('#successAlert').show();		
				$('#sucessText').text(data.name).show();
				$('#errorAlert').hide();
				$("#mylink").attr("href", data.search);
                let myurl = "url('" + data.iurl + "')" 		
                $("#successAlert").css("background", myurl);
			}	

		});

		event.preventDefault();

	});

	$('#addSeriesForm').on('submit', function(event) {
		
		$.ajax({
			data : {
				name : $('#sName').val(),
				description : $('#Sdescription').val(),
				hero : $('#sHero').val(),
				image: $('#sImage').val(),
				url: $('#sUrl').val(),
				date: $('#sDate').val(),
				menuid: $('#sMenuId').val()
				
			},
			type : 'POST',
			url : '/addprocess'
		})
		.done(function(data) {

			if (data.error) {
				$('#errorAlertAdd').text(data.error).show();
				$('#successAlertAdd').hide();
				$('#udContiner2').hide();
				
			}
			else {
				$('#successAlertAdd').show();
				$('#udContiner2').show()				
				$('#sucessTextAddSeries').text(data.respond).show();	//data.respond
				
				document.querySelector('.hideme').display = "block";
				$('#errorAlertAdd').hide();                				
                let addurl = "url('" + data.iurl + "')" 		
                $("#successAlertAdd").css("background", addurl);
				$("#successAlertAdd").css("background-size", "cover");
				$("#successAlertAdd").css("background-repeat", "no-repeat;");
				$("#successAlertAdd").css("height", "400px");				
				$('#successAlertfooter').text("After Finish all your adding \n refreash the page").show();
				$("#successAlertfooter").css("color", "white");
				$("#successAlertfooter").css("width", "300px");
				$("#successAlertfooter").css("height", "auto");
				$("#successAlertfooter").css("padding", "10px");
				$("#successAlertfooter").css("background-color", "gold");
				$("#successAlertfooter").css("font-weight", "bold");
			}	

		});

		event.preventDefault();

	});
    
    $('#addEPosideForm').on('submit', function(event) {
		
		$.ajax({
			data : {
				seid : $('#itid').val(),
				getname : $('#epName').val(),
				getserver : $('#epserver').val(),
				server2 : $('#epserver2').val()
			},
			type : 'POST',
			url : '/addeposide'
		})
		.done(function(data) {

			if (data.error) {
				$('#errorAlertAdd').text(data.error).show();
				$('#successAlertAdd').hide();
				$('#udContiner2').hide();
				
			}
			else {
				$('#successAlertAdd').show();
				$('#udContiner2').show()				
				$('#sucessTextAddSeries').text(data.respond).show();	//data.respond		

			}	

		});

		event.preventDefault();

	});
	
	
	$('#movieform').on('submit', function(event) {
		
		$.ajax({
			data : {
				mname : $('#mName').val(),
				mdescription : $('#mDescription').val(),
				mhero : $('#mHero').val(),
				mimage: $('#mImage').val(),
				murl: $('#mUrl').val(),
				mdate: $('#mDate').val(),
				mmenuid: $('#mMenuId').val()
				
			},
			type : 'POST',
			url : '/movieprocess'
		})
		.done(function(data) {

			if (data.error) {
				$('#errorAlertAdd').text(data.error).show();
				$('#successAlertMovie').hide();
				$('#udContiner2').hide();
				
				
			}
			else {
				$('#successAlertMovie').show();		
				$('#sucessTextAddMovie').text(respond.name).show();
				$('#errorAlertAddMovie').hide();				
                let addurl = "url('" + data.iurl + "')" 		
                $("#successAlertMovie").css("background", addurl);
				
			}	

		});

		event.preventDefault();

	});	
	
});


var hider = document.getElementById("#udContiner");

$(document).ready(function(){
  $("#searchbtn").click(function(){
  
  let test = $('#txt_search').val();
  if (test != '') {
    $("#udContiner").toggle();
    }
  if (test == '') {
    $("#udContiner").hide();
    }  
  });
});

var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

const infoSign = document.getElementById("plus_sign");
const infoText = document.getElementById("mytext");
const closerBtn = document.getElementById("closebtn_info");

function hidSign() {
   infoSign.style.display = "none";
   infoText.style.display = "block"; 
   closerBtn.style.display = "block";

}

function showSign() {
   infoSign.style.display = "block";
   infoText.style.display = "none";
   closerBtn.style.display = "none";

}


function scrollWin() {
  window.scrollBy(0, 250);
}


document.getElementById("myghrapich").addEventListener("mouseover", hidSign);
document.getElementById("myghrapich").addEventListener("mouseout", showSign);

document.getElementById("myghrapich").addEventListener("mouseenter", scrollWin);



//Get the button
var mybutton = document.getElementById("myBtnBack");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}